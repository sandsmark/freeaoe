#!/usr/bin/python
vers = '0-beta1'

from Tkinter import *
from tkFileDialog import askopenfilename
from tkColorChooser import askcolor
from tkSimpleDialog import askstring
from SLPLib import *
from SLPPal import pal

from sys import argv, exit
from os import system

import Image, ImageDraw, ImageFile

print "SLPTool, a graphical interactive SLP viewer and extractor written in Python, by Bryce Schroeder. Version: %s" % vers

class memory: # Don't ask.
	xsize = 5
	ysize = 10
SLPSize = memory()


class SLPWrapper:
	def __init__(self, slp, n):
		"""This class is a wrapper around the actual SLPImage class."""
		self.slp = slp
		self.id = n
		self.rendered = 0
		self.noImage = 0
		self.size = self.slp.size
		self.name = '%s %d*%d' % (self.id, self.size[0], self.size[1])
		self.image = Image.new('RGB', self.size)
		self.slp.load()
		self.updated = 0
	def show(self):
		if not self.rendered or not self.updated:
			self.draw()
		self.image.show()
	def draw(self):
		""" Defaults wrapper for render()."""
		self.render(self.xflip, self.bgcolor, self.out1color,
			self.out2color, self.palette)
		
	def render(self, xflip, bgcolor, out1color, out2color, palette):
		shadow = (bgcolor[0]/2,bgcolor[1]/2,bgcolor[2]/2)
		# The shadow is darker than the background
		# bgcolor, shadow, outXcolor, are triplets w/ RGB data.
		data = self.slp.rasterize(pcolor=0, amXflip=xflip)
		self.pad = ImageDraw.Draw(self.image)
		x = 0
		while x < self.size[0]: #tricky, tricky, tricky!
			y = 0
			while y < self.size[1]:
				pix = data[y][x]
				if  pix == 'P-C':
					color = out1color
				elif pix == 'S-D':
					color = out2color
				elif pix == 'SH':
					color = shadow
				elif pix == None:
					color = bgcolor
				else: 
					if not self.noImage:
						color = palette[ord(pix)]
					else:
						color = self.bgcolor
				self.pad.point((x,y), fill=color)
				y += 1
			x += 1
		self.rendered = 1
		self.updated = 1
		
	def settings(self, xflip=None, bg=None, out1=None, out2=None, pal=None, noImage=None, noOutline=None):
		if xflip != None:
			self.xflip = xflip
		if bg != None:
			self.bgcolor = bg
		if out1 != None:
			self.out1color = out1
		if out2 != None:
			self.out2color = out2
		if pal != None:
			self.palette = pal
		if noImage != None:
			self.noImage = noImage 
		if noOutline != None: # make the outlines invisible.
			self.out1color = self.bgcolor
			self.out2color = self.bgcolor
		self.updated = 0



try:		
	loc = argv[1]
except IndexError:
	root = Tk()
	loc = askopenfilename()
else:
	root = Tk() # Has to be done before the first call to the gui

try:
	slpFile = SLP(loc)
except IOError:
	print "Bogus filename `%s'." % loc
	exit(1)

try:
	slpFile.load()
except SLP_Error: #Catch this error when the [l]user opens up a
		  #a text file or something. Once in a while not-SLP file
		  # triggers SLP_Unimplemented as well via the pallate offset.
	print "Bad SLP file!" #But we don't want to catch that because
	exit(1)		      # maybe it really is a SLP file with a palate.

shapes = []
n = 0
for shape in slpFile.shapes:
	n += 1
	shapes.append(SLPWrapper(shape, '%03d | '%n))
	
shapes[0].settings(xflip=1, bg=(155,155,255), out1=(64,255,128), out2=(64,128,255), pal=pal[0])
shapes[0].show()


# default settings
curShape = 0



# Bring on the callbacks!
def showall():
	# copy current settings:
	cur = shapes[curShape]
	for shape in shapes:
		shape.settings(xflip=cur.xflip, bg=cur.bgcolor, out1=cur.out1color, 
			out2=cur.out2color, pal=cur.palette)
		shape.show()
def displayButton():
	old = shapes[curShape]
	exec 'curShape = int(shapelist.get(ACTIVE)[0:3]) - 1'  # again, don't ask.
	shapes[curShape].settings(xflip=old.xflip, bg=old.bgcolor, out1=old.out1color,
		out2=old.out2color, pal=old.palette, noImage = old.noImage)
	shapes[curShape].show()
def askDimensions():
	tmp = askstring("Enter matrix dimensions...", 'Example: 10 5').split(' ')
	SLPSize.xsize = int(tmp[0])
	SLPSize.ysize = int(tmp[1])
###

root.title("SLP Viewer Tool")


topmenu = Menu(root)

list = Frame(root)

scrollbar = Scrollbar(list)
shapelist = Listbox(list)

for shape in shapes:
	shapelist.insert(END, shape.name)

shapelist.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=shapelist.yview)
Label(list, text="%d Images" % slpFile.numShapes).pack(side=TOP)
shapelist.pack(side=LEFT, fill=X)
scrollbar.pack(side=RIGHT, fill=Y)
list.pack(side=TOP)


Checkbutton(root, text='X-Flip', command=(
	lambda: shapes[curShape].settings(xflip=(not shapes[curShape].xflip))
	)).pack(side=RIGHT)
Checkbutton(root, text='Don\'t Draw Image', command=(
	lambda: shapes[curShape].settings(noImage=(not shapes[curShape].noImage))
	)).pack(side=RIGHT)

Button(root, command=(lambda: exit(0)), text='Quit').pack(side=LEFT)
Button(root, command=(lambda: system("unslp %s %d %d" % (loc, SLPSize.xsize, SLPSize.ysize)) ), text='Matrix' ).pack(side=RIGHT)
Button(root, command=displayButton, text='Display').pack(fill=X)


Background = Menu()
Background.add_command(label="Black - 0,0,0", command=(
	lambda: shapes[curShape].settings(bg=(0,0,0)) )
	)
Background.add_command(label="Seafoam - 64,160,128", command=(
	lambda: shapes[curShape].settings(bg=(64,160,128)) )
	)
Background.add_command(label="Pink - 255,128,255", command=(
	lambda: shapes[curShape].settings(bg=(255,128,255)) )
	)
Background.add_command(label="White - 255,255,255", command=(
	lambda: shapes[curShape].settings(bg=(255,255,255)) )
	)
Background.add_separator()
Background.add_command(label="Custom...", command=(
	lambda: shapes[curShape].settings(bg=askcolor()[0]) )
	)


Palette = Menu()
Palette.add_command(label="Standard - 0", command=(
	lambda: shapes[curShape].settings(pal=pal[0]) )
	)
Palette.add_separator()
i = 1
while i < 7:
	Palette.add_command(label="Palette %d" % i, command=(
		lambda: shapes[curShape].settings(pal=pal[i]) )
		)
	i += 1
Palette.add_separator()
Palette.add_command(label="Palette from file...", command=(
	lambda: exit(2))
		)

Outline = Menu()
Outline.add_command(label="White & Lavender", command=(
	lambda: shapes[curShape].settings(out1=(255,255,255), out2=(200,100,250)) )
	)
Outline.add_command(label="Orange & Red", command=(
	lambda: shapes[curShape].settings(out1=(255,200,0), out2=(255,0,0)) )
	)
Outline.add_command(label="Green & Blue", command=(
	lambda: shapes[curShape].settings(out1=(0,255,0), out2=(0,0,255)) )
	)
Outline.add_command(label="Black & White", command=(
	lambda: shapes[curShape].settings(out1=(0,0,0), out2=(255,255,255)) )
	)
Outline.add_separator()
Outline.add_command(label="No Outline", command=(
	lambda: shapes[curShape].settings(noOutline=1) )
	)

Image = Menu()
Image.add_command(label="Refresh", command=displayButton)
Image.add_command(label="Quit", command=(lambda: exit(0)))
Image.add_command(label="Show All", command=showall)
Image.add_separator()
Image.add_command(label="View With unslp", command=(
	lambda: system("unslp %s %d %d" % (loc, SLPSize.xsize, SLPSize.ysize)) )
	)
Image.add_command(label="Enter dimensions...", command=askDimensions)

topmenu.add_cascade(label='Image', menu=Image)
topmenu.add_cascade(label='Background', menu=Background)
topmenu.add_cascade(label='Palette', menu=Palette)
topmenu.add_cascade(label='Outline', menu=Outline)




root.config(menu=topmenu)

root.mainloop()

