GeniEd2 source code
===================

This code is provided primarily for entertainment and not really
with much expectation of people compiling it. But in case you do,
I've (hopefully) included the full VS2003 project files; if you
can't use them, it's not too hard to make your own in some other
IDE.

You'll also need wxWindows (www.wxwindows.org) - I used version
2.4.2, with a few minor changes (at the end of this file).



Just to be revolutionary, the code isn't released under any
particular licence. Choose any that you like, as long as it's
not particularly unfair to me.


--
Ykkrosh (ykkrosh@zaynar.demon.co.uk)





Alterations to wxWindows' src/regex/regex.cpp and include/wx/regex.h

--- old/regex.cpp   2003-08-25 15:24:12.000000000 +0100
+++ new/regex.cpp   2004-05-25 09:33:44.000000000 +0100
@@ -165,7 +165,7 @@
 
     // translate our flags to regcomp() ones
     wxASSERT_MSG( !(flags &
-                        ~(wxRE_BASIC | wxRE_ICASE | wxRE_NOSUB | wxRE_NEWLINE)),
+                        ~(wxRE_BASIC | wxRE_ICASE | wxRE_NOSUB | wxRE_NEWLINE | wxRE_NOCOMPLAIN)),
                   _T("unrecognized flags in wxRegEx::Compile") );
 
     int flagsRE = 0;
@@ -182,8 +182,9 @@
     int errorcode = regcomp(&m_RegEx, expr.mb_str(), flagsRE);
     if ( errorcode )
     {
-        wxLogError(_("Invalid regular expression '%s': %s"),
-                   expr.c_str(), GetErrorMsg(errorcode).c_str());
+        if ( !(flags & wxRE_NOCOMPLAIN) )
+           wxLogError(_("Invalid regular expression '%s': %s"),
+                      expr.c_str(), GetErrorMsg(errorcode).c_str());
 
         m_isCompiled = FALSE;
     }



--- old/regex.h 2002-08-31 13:29:12.000000000 +0100
+++ new/regex.h 2004-05-25 09:32:06.000000000 +0100
@@ -47,7 +47,10 @@
     wxRE_NEWLINE  = 16,
 
     // default flags
-    wxRE_DEFAULT  = wxRE_EXTENDED
+    wxRE_DEFAULT  = wxRE_EXTENDED,
+
+
+   wxRE_NOCOMPLAIN = 128
 };
 
 // flags for regex matching: these can be used with Matches()
