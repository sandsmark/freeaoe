#include "wx/wxprec.h"
#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "unit.h"
#include "structs.h"

class UnitPanel : public wxScrolledWindow
{
public:
	UnitPanel(wxWindow *parent, GenieUnit *Unit);
	bool UnitPanel::SwitchAway();
	~UnitPanel();

	void RemoveUnit() { Unit = NULL; }

	void OnUnitCancel(wxCommandEvent& event);

	GenieUnit *Unit;
	genie_unit *UnitData;
private:
	DECLARE_EVENT_TABLE()

};

enum
{
	ID_Unit_Cancel = 1,
};