#pragma once

#include "buffer.h"
#include <string>
#include <list>
#include <vector>

#include "wx/string.h"
#include "language.h"

class GenieUnit
{
public:
	Buffer *DataBuffer;
	LanguageDLL *LangDLL;
	wxString DisplayName;
	int Id;
	int FileOffset;
	int VersionNum;
	typedef std::vector<wxString> SearchablesType;
	SearchablesType Searchables;

	bool operator<(GenieUnit &a) {
		return DisplayName < a.DisplayName || Id < a.Id;
	}

};

class GenieCiv
{
public:
	std::string Title;

	typedef std::list<GenieUnit> UnitsType;
	UnitsType Units;

};