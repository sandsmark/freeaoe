open H, 'help.html' or die;
open O, '> help.cpp' or die;

$d = do { local $/; <H> };
$d =~ s/\\/\\\\/g;
$d =~ s/"/\\"/g;
$d =~ s/\n/\\n/g;

print O qq{// auto-generated from help.html by help.pl\n\nwxString HtmlHelp = wxT("$d");\n};
