#include "wxunit.h"
#include "wx/regex.h"

#include "wxvalidators.h"

#define STAT_SHORT(name, thing) \
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	Sizer->Add(new ValidatingTextCtrl(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NumShortValidator(&##thing)), 0, wxALL, 4)

#define STAT_CHAR(name, thing) \
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	Sizer->Add(new ValidatingTextCtrl(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NumCharValidator(&##thing)), 0, wxALL, 4)

#define STAT_CBOOL(name, thing)	\
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	Sizer->Add(new wxCheckBox(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NumBoolValidator<char>(&##thing)), 0, wxALL, 4)

#define STAT_SBOOL(name, thing) \
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	Sizer->Add(new wxCheckBox(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NumBoolValidator<short>(&##thing)), 0, wxALL, 4)

#define STAT_FLOAT(name, thing) \
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	Sizer->Add(new ValidatingTextCtrl(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NumFloatValidator(&##thing)), 0, wxALL, 4)


/*
#define STAT_RESRC(name, thing) \
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	{	wxListBox *cb = new wxComboBox(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 5, ResourceNames, wxCB_READONLY, ResourceListValidator(&##thing)); \
		lb->Set(*ResourceNames); \
		Sizer->Add(lb, 0, wxALL, 4); }
*/
#define STAT_RESRC(name, thing) \
	Sizer->Add(new wxStaticText(this, -1, wxT(name)), 0, wxALIGN_RIGHT | wxALL, 4); \
	Sizer->Add(new wxComboBox(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 5, ResourceNames, wxCB_READONLY, ResourceListValidator(&##thing)), 0, wxALL, 4)

BEGIN_EVENT_TABLE(UnitPanel, wxScrolledWindow)
	EVT_BUTTON(ID_Unit_Cancel, UnitPanel::OnUnitCancel)
END_EVENT_TABLE()


UnitPanel::UnitPanel(wxWindow *parent, GenieUnit *Unit_)
	: wxScrolledWindow(parent, -1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL | wxNO_BORDER | wxVSCROLL)
{
	UnitData = NULL;
	Unit = Unit_;

	if (! Unit)
		return;

	UnitData = new genie_unit;

	Unit->DataBuffer->seek(Unit->FileOffset);
	UnitData->Read(Unit->DataBuffer, Unit->VersionNum);


	wxBoxSizer *MainSizer = new wxBoxSizer(wxVERTICAL);

	MainSizer->Add(new wxButton(this, ID_Unit_Cancel, wxT("Undo all changes")), 0, wxALL | wxALIGN_CENTER, 4);

	wxFlexGridSizer *Sizer = new wxFlexGridSizer(2);

	Sizer->AddGrowableCol(1);

	Sizer->Add(new wxStaticText(this, -1, wxT("Unit ID")), 0, wxALIGN_RIGHT | wxALL, 4);
	Sizer->Add(new wxTextCtrl(this, -1, wxString::Format(wxT("%d"), Unit->Id), wxDefaultPosition, wxDefaultSize, wxTE_READONLY), 0, wxALL, 4);

	Sizer->Add(new wxStaticText(this, -1, wxT("Internal name")), 0, wxALIGN_RIGHT | wxALL, 4);
	Sizer->Add(new wxTextCtrl(this, -1, wxString::FromAscii(UnitData->name1), wxDefaultPosition, wxDefaultSize, wxTE_READONLY), 0, wxEXPAND | wxALL, 4);

	if (Unit->VersionNum == 59)
	{
		Sizer->Add(new wxStaticText(this, -1, wxT("Internal name (AI)")), 0, wxALIGN_RIGHT | wxALL, 4);
		Sizer->Add(new wxTextCtrl(this, -1, wxString::FromAscii(UnitData->name2), wxDefaultPosition, wxDefaultSize, wxTE_READONLY), 0, wxEXPAND | wxALL, 4);
	}

	Sizer->Add(new wxStaticText(this, -1, wxT("Language DLL ID")), 0, wxALIGN_RIGHT | wxALL, 4);
	wxBoxSizer *LangDLLSizer = new wxBoxSizer(wxHORIZONTAL);
	wxStaticText *LanguageNameCtrl = new wxStaticText(this, -1, Unit->LangDLL->GetString(UnitData->head.language).c_str());
	//LangDLLSizer->Add(new wxTextCtrl(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NumShortValidator(&UnitData->head.language)));
	LangDLLSizer->Add(new ValidatingTextCtrl(this, -1, wxT(""), wxDefaultPosition, wxDefaultSize, 0, LanguageValidator(LanguageNameCtrl, Unit->LangDLL, &UnitData->head.language)));
	LangDLLSizer->Add(LanguageNameCtrl, 1, wxEXPAND | wxALL, 4);
	Sizer->Add(LangDLLSizer, 0, wxEXPAND | wxALL, 4);

	//////

	wxString ResourceNames[] = { wxT("Unused"), wxT("Food"), wxT("Carbon / Wood"), wxT("Ore / Stone"), wxT("Nova / Gold") };

	//////

	STAT_SHORT("Hitpoints", UnitData->head.hitpoints);
	STAT_FLOAT("Line of sight", UnitData->head.lineofsight);
	STAT_CHAR("Garrison capacity", UnitData->head.garrison);
	STAT_SHORT("Icon ID", UnitData->head.icon);
	STAT_CBOOL("Hide from editor", UnitData->head.notineditor);

	STAT_SHORT("Dead unit ID", UnitData->head.deadunit);

	//////

	if (UnitData->type != 10)
	{
		STAT_FLOAT("Movement speed", UnitData->part2->speed);
	}

	//////

	if (UnitData->type == 70)
	{
		STAT_FLOAT("Attack range (displayed)", UnitData->part14->attack_range_displayed);
		STAT_FLOAT("Attack range", UnitData->part10->attack_range);
		STAT_FLOAT("Blast radius", UnitData->part10->attack_radius);
		STAT_SHORT("Projectile unit ID", UnitData->part10->projectile);
		STAT_FLOAT("Reload time (1)", UnitData->part10->attack_reload01);
		STAT_FLOAT("Reload time (2)", UnitData->part14->attack_reload02);
	}

	//////

	if (UnitData->type == 70 || UnitData->type == 80)
	{
		STAT_SHORT("Armour (displayed)", UnitData->part12->armour_displayed);
		STAT_SHORT("Attack (displayed)", UnitData->part12->attack_displayed);
	}

	if (UnitData->type == 70)
	{
		STAT_SBOOL("Cost 1 used", UnitData->part14->cost_01_used);
		STAT_RESRC("Cost 1 type", UnitData->part14->cost_01_type);
		STAT_SHORT("Cost 1 amount", UnitData->part14->cost_01_amount);

		STAT_SBOOL("Cost 2 used", UnitData->part14->cost_02_used);
		STAT_RESRC("Cost 2 type", UnitData->part14->cost_02_type);
		STAT_SHORT("Cost 2 amount", UnitData->part14->cost_02_amount);

		STAT_SHORT("Construction time", UnitData->part14->cost_time);
	}

	if (UnitData->type == 80)
	{
		STAT_SBOOL("Cost 1 used", UnitData->part11->cost_01_used);
		STAT_RESRC("Cost 1 type", UnitData->part11->cost_01_type);
		STAT_SHORT("Cost 1 amount", UnitData->part11->cost_01_amount);

		STAT_SBOOL("Cost 2 used", UnitData->part11->cost_02_used);
		STAT_RESRC("Cost 2 type", UnitData->part11->cost_02_type);
		STAT_SHORT("Cost 2 amount", UnitData->part11->cost_02_amount);

		STAT_SBOOL("Cost 3 used", UnitData->part11->cost_03_used);
		STAT_RESRC("Cost 3 type", UnitData->part11->cost_03_type);
		STAT_SHORT("Cost 3 amount", UnitData->part11->cost_03_amount);

		STAT_SHORT("Construction time", UnitData->part11->cost_time);
	}

	//////

	if (UnitData->type == 70)
	{
		STAT_SHORT("Dura-armour (displayed)", UnitData->part14->duraarmour_displayed);
	}

	//////

	MainSizer->Add(Sizer, 0, wxEXPAND);

	MainSizer->Add(new wxWindow(this, -1, wxDefaultPosition, wxSize(32, 32)), 0);

	//EnableScrolling(false, true);
	SetScrollRate(0, 15);
	SetSizer(MainSizer);

	InitDialog();
}

bool UnitPanel::SwitchAway()
{
	if (! Unit)
		return true;

	if (! Validate())
		return false;

	TransferDataFromWindow();

	Unit->DataBuffer->seek(Unit->FileOffset);
	UnitData->Write(Unit->DataBuffer, Unit->VersionNum);

	return true;
}

void UnitPanel::OnUnitCancel(wxCommandEvent& event)
{
	TransferDataToWindow();
}


UnitPanel::~UnitPanel()
{
	delete UnitData;
}