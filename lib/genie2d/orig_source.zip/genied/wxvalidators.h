#include "language.h"

#include <limits.h>
#include <float.h>

#define ValidateError(s) { ValidatingTextCtrl::IgnoreFocusLoss = true; wxSafeShowMessage(wxT("Input error"), s); ValidatingTextCtrl::IgnoreFocusLoss = false; }

class ValidatingTextCtrl : public wxTextCtrl
{
public:
	static bool IgnoreFocusLoss;

	ValidatingTextCtrl(wxWindow *parent, wxWindowID id, const wxString& value = wxEmptyString, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = 0, const wxValidator& validator = wxDefaultValidator, const wxString& name = wxTextCtrlNameStr)
		: wxTextCtrl(parent, id, value, pos, size, style, validator, name),
		  InitialValue (value)
	{
	}

	void SetInitialValue(const wxString& value)
	{
		InitialValue = value;
		SetValue(value);
	}

	void OnKillFocus(wxFocusEvent& event)
	{
		if (IgnoreFocusLoss)
		{
			event.Skip();
			return;
		}

		if (GetValidator()->Validate(NULL))
		{
		}
		else
		{
			SetFocus();
		}
		event.Skip();
	}

	void OnKeyDown(wxKeyEvent& event)
	{
		if (event.GetKeyCode() == WXK_ESCAPE)
			SetValue(InitialValue);
		else
			event.Skip();
	}

private:
	DECLARE_EVENT_TABLE()

	wxString InitialValue;
};

enum
{
	ID_Text_Escaped = 1,
};

BEGIN_EVENT_TABLE(ValidatingTextCtrl, wxTextCtrl)
	EVT_KILL_FOCUS(ValidatingTextCtrl::OnKillFocus)
	EVT_KEY_DOWN(ValidatingTextCtrl::OnKeyDown)
END_EVENT_TABLE()

bool ValidatingTextCtrl::IgnoreFocusLoss = false;

///////////////////////////

// Too much code duplication to be happy with, too little to be worth fixing.

class NumShortValidator : public wxValidator
{
public:
	NumShortValidator(short *num) 
		: wxValidator()
	{
		Value = num;
	}

protected:
	short *Value;

private:
	bool TransferToWindow()
	{
		((ValidatingTextCtrl *)GetWindow())->SetInitialValue(wxString::Format(wxT("%d"), *Value));
		return true;
	}

	bool TransferFromWindow()
	{
		//		GetWindow()->SetValue(wxString::Format("%i", num));
		long num;
		wxString str ( ((wxTextCtrl *)GetWindow())->GetValue() );
		if ( str.ToLong(&num) )
			*Value = num;
		return true;
	}

	wxObject *Clone() const
	{
		return new NumShortValidator(Value);
	}

	bool Validate(wxWindow *parent)
	{
		long num;
		wxString str ( ((wxTextCtrl *)GetWindow())->GetValue() );
		
		if (! str.ToLong(&num))
		{
			ValidateError(wxString::Format(wxT("Invalid integer '%s'"), str));
			return false;
		}
		if (num < SHRT_MIN || num > SHRT_MAX)
		{
			ValidateError(wxString::Format(wxT("Number '%d' outside valid range (%d..%d)"), num, SHRT_MIN, SHRT_MAX));
			return false;
		}
		return true;
	}
};

///////////////////////////

class NumCharValidator : public wxValidator
{
public:
	NumCharValidator(char *num)
		: wxValidator()
	{
		Value = num;
	}

protected:
	char *Value;

private:
	bool TransferToWindow()
	{
		((ValidatingTextCtrl *)GetWindow())->SetInitialValue(wxString::Format(wxT("%d"), *Value));
		return true;
	}

	bool TransferFromWindow()
	{
		//		GetWindow()->SetValue(wxString::Format("%i", num));
		long num;
		wxString str ( ((wxTextCtrl *)GetWindow())->GetValue() );
		if ( str.ToLong(&num) )
			*Value = num;
		return true;
	}

	wxObject *Clone() const
	{
		return new NumCharValidator(Value);
	}

	bool Validate(wxWindow *parent)
	{
		long num;
		wxString str ( ((wxTextCtrl *)GetWindow())->GetValue() );

		if (! str.ToLong(&num))
		{
			ValidateError(wxString::Format(wxT("Invalid integer '%s'"), str));
			return false;
		}
		if (num < CHAR_MIN || num > CHAR_MAX)
		{
			ValidateError(wxString::Format(wxT("Number '%d' outside valid range (%d..%d)"), num, CHAR_MIN, CHAR_MAX));
			return false;
		}
		return true;
	}
};
///////////////////////////

class NumFloatValidator : public wxValidator
{
public:
	NumFloatValidator(float *num) 
		: wxValidator()
	{
		Value = num;
	}

protected:
	float *Value;

private:
	bool TransferToWindow()
	{
		((ValidatingTextCtrl *)GetWindow())->SetInitialValue(wxString::Format(wxT("%.3f"), *Value));
		return true;
	}

	bool TransferFromWindow()
	{
		//		GetWindow()->SetValue(wxString::Format("%i", num));
		double num;
		wxString str ( ((wxTextCtrl *)GetWindow())->GetValue() );
		if ( str.ToDouble(&num) )
			*Value = (float)num;
		return true;
	}

	wxObject *Clone() const
	{
		return new NumFloatValidator(Value);
	}

	bool Validate(wxWindow *parent)
	{
		double num;
		wxString str ( ((wxTextCtrl *)GetWindow())->GetValue() );

		if (! str.ToDouble(&num))
		{
			ValidateError(wxString::Format(wxT("Invalid number '%s'"), str));
			return false;
		}
		if (num < -FLT_MAX || num > FLT_MAX)
		{
			ValidateError(wxString::Format(wxT("Number '%e' outside valid range (%e..%e)"), num, -FLT_MAX, FLT_MAX));
			return false;
		}
		return true;
	}
};

///////////////////////////

class LanguageValidator : public NumShortValidator
{
public:
	LanguageValidator(wxStaticText *text, LanguageDLL *lang, short *num)
		: NumShortValidator(num)
	{
		TextCtrl = text;
		LangDLL = lang;
	}

	wxObject *Clone() const
	{
		return new LanguageValidator(TextCtrl, LangDLL, Value);
	}

	void OnKeyUp(wxKeyEvent& event)
	{
		unsigned long ID;
		if (( (wxTextCtrl*)GetWindow())->GetValue().ToULong(&ID) )
		{
			wxString LangName = LangDLL->GetString(ID).c_str();
			if (! LangName.Length())
				LangName = wxT("[not found]");
			TextCtrl->SetLabel(LangName);
		}

		event.Skip();
	}

private:
	DECLARE_EVENT_TABLE()

	wxStaticText *TextCtrl;
	LanguageDLL *LangDLL;
};

///////////////////////////

template<typename T>
class NumBoolValidator : public wxValidator
{
public:
	NumBoolValidator(T *num)
		: wxValidator()
	{
		Value = num;
	}

protected:
	T *Value;

private:
	bool TransferToWindow()
	{
		((wxCheckBox *)GetWindow())->SetValue(*Value ? true : false);
		return true;
	}

	bool TransferFromWindow()
	{
		*Value = ((wxCheckBox *)GetWindow())->GetValue() ? 1 : 0;
		return true;
	}

	wxObject *Clone() const
	{
		return new NumBoolValidator(Value);
	}

	bool Validate(wxWindow *parent)
	{
		return true;
	}
};

///////////////////////////

class ResourceListValidator : public wxValidator
{
public:
	ResourceListValidator(short *num)
		: wxValidator()
	{
		Value = num;
	}

protected:
	short *Value;

private:
	bool TransferToWindow()
	{
		((wxComboBox *)GetWindow())->SetSelection(*Value + 1);
		return true;
	}

	bool TransferFromWindow()
	{
		*Value = ((wxComboBox *)GetWindow())->GetSelection() - 1;
		return true;
	}

	wxObject *Clone() const
	{
		return new ResourceListValidator(Value);
	}

	bool Validate(wxWindow *parent)
	{
		return true;
	}
};

///////////////////////////

BEGIN_EVENT_TABLE(LanguageValidator, NumShortValidator)
	EVT_KEY_UP(LanguageValidator::OnKeyUp)
END_EVENT_TABLE()
