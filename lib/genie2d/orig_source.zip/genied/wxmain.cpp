#include "genied.h"
#include "wxmain.h"

#include "wx/html/htmlwin.h"
#include "wx/filename.h"
#include "wx/file.h"


//#define alert(s) { wxMessageDialog m (this, s, wxT("Alert"), wxOK); m.ShowModal(); }

#define ErrorMessage(s) { wxMessageDialog m (this, s, wxT("Error"), wxOK | wxCENTER | wxICON_EXCLAMATION); m.ShowModal(); }

UnitListBox::UnitListBox(wxWindow *parent, wxWindowID id = -1)
: wxListBox(parent, id, wxDefaultPosition, wxDefaultSize, 0, NULL, wxLB_SINGLE | wxLB_ALWAYS_SB)
{
}

CivComboBox::CivComboBox(wxWindow *parent, wxWindowID id = -1)
: wxComboBox(parent, id, wxT(""), wxDefaultPosition, wxDefaultSize, 0, NULL, wxCB_DROPDOWN | wxCB_READONLY)
{
}


bool MyApp::OnInit()
{
	genie = NULL;
	CurrentCiv = NULL;
	// Load the config settings
	wxConfig *config = new wxConfig(wxT("GeniEd2"));
	wxConfig::Set(config);

	MyFrame *frame = new MyFrame(wxT("GeniEd2"), wxPoint(50,50), wxSize(640,480));
	frame->Show(TRUE);
	SetTopWindow(frame);

	return true;
}

int MyApp::OnExit()
{
	delete genie;
	delete wxConfig::Get();

	return 0;
}


///////////////////////

OpenDialog::OpenDialog(wxWindow *parent)
	: wxDialog(parent, -1, wxT("Open data files"), wxDefaultPosition, wxSize(500, 250), wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER | wxNO_DEFAULT)
{
	wxButton *OkayButton = new wxButton(this, wxID_OK, wxT("OK"));

	wxBoxSizer *MainSizer = new wxBoxSizer(wxVERTICAL);

	wxBoxSizer *DefaultsSizer = new wxBoxSizer(wxHORIZONTAL);
	DefaultsSizer->Add(new wxButton(this, ID_Open_Default_SWGB, wxT("SWGB defaults")), 0, wxALIGN_CENTER | wxALL, 8);
	DefaultsSizer->Add(new wxButton(this, ID_Open_Default_SWGBCC, wxT("SWGB:CC defaults")), 0, wxALIGN_CENTER | wxALL, 8);
	DefaultsSizer->Add(new wxButton(this, ID_Open_Default_AOKTC, wxT("AoK:TC defaults")), 0, wxALIGN_CENTER | wxALL, 8);
	MainSizer->Add(DefaultsSizer, 0, wxALIGN_CENTER);

	MainSizer->Add(new wxWindow(this, -1), 1);

	// Draw the genie/lang/langx1 boxes

	wxConfig *config = (wxConfig *)wxConfig::Get();
	wxString GeniePath, LangPath, LangX1Path;
	config->Read(wxT("GeniePath"),	&GeniePath);
	config->Read(wxT("LangPath"),	&LangPath);
	config->Read(wxT("LangX1Path"),	&LangX1Path);

	wxFlexGridSizer *FilesSizer = new wxFlexGridSizer(3);
	FilesSizer->AddGrowableCol(1);

	FilesSizer->Add(new wxStaticText(this, -1, wxT(".dat file")), 0, wxALIGN_RIGHT | wxALL, 2);
	FilenameGenie = new wxTextCtrl(this, -1, GeniePath);
	FilesSizer->Add(FilenameGenie, 0, wxALIGN_RIGHT | wxEXPAND | wxALL, 2);
	FilesSizer->Add(new wxButton(this, ID_Open_Browse_Genie, wxT("Browse...")), 0, wxALL, 2);

	FilesSizer->Add(new wxStaticText(this, -1, wxT("language.dll")), 0, wxALIGN_RIGHT | wxALL, 2);
	FilenameLang = new wxTextCtrl(this, -1, LangPath);
	FilesSizer->Add(FilenameLang, 0, wxALIGN_RIGHT | wxEXPAND | wxALL, 2);
	FilesSizer->Add(new wxButton(this, ID_Open_Browse_Lang, wxT("Browse...")), 0, wxALL, 2);

	FilesSizer->Add(new wxStaticText(this, -1, wxT("language_x1.dll")), 0, wxALIGN_RIGHT | wxALL, 2);
	FilenameLangX1 = new wxTextCtrl(this, -1, LangX1Path);
	FilesSizer->Add(FilenameLangX1, 0, wxALIGN_RIGHT | wxEXPAND | wxALL, 2);
	FilesSizer->Add(new wxButton(this, ID_Open_Browse_LangX1, wxT("Browse...")), 0, wxALL, 2);

	MainSizer->Add(FilesSizer, 0, wxALIGN_CENTER | wxEXPAND);

	MainSizer->Add(new wxWindow(this, -1), 1);

	wxBoxSizer *ButtonsSizer = new wxBoxSizer(wxHORIZONTAL);
	ButtonsSizer->Add(OkayButton, 0, wxALIGN_CENTER | wxALL, 8);
	ButtonsSizer->Add(new wxButton(this, wxID_CANCEL, wxT("Cancel")), 0, wxALIGN_CENTER | wxALL, 8);
	MainSizer->Add(ButtonsSizer, 0, wxALIGN_CENTER);

	SetSizer(MainSizer);

	OkayButton->SetDefault();
	OkayButton->SetFocus();
}

OpenDialog::~OpenDialog()
{
	/*	
	for (deletable_type::iterator i = deletable.begin(); i != deletable.end(); ++i)
		delete (*i);
	deletable.clear();
	*/
}

void OpenDialog::OnOK(wxCommandEvent& WXUNUSED(event))
{
	wxConfig *config = (wxConfig *)wxConfig::Get();
	wxString GeniePath = FilenameGenie->GetValue();
	wxString LangPath = FilenameLang->GetValue();
	wxString LangX1Path = FilenameLangX1->GetValue();

	if (GeniePath == wxT(""))
	{
		ErrorMessage(wxT("A .dat file must be chosen."));
		return;
	}
	if (! wxFileExists(GeniePath))
	{
		ErrorMessage(wxT("Specified .dat file does not exist."));
		return;
	}
	if (LangPath != wxT("") && ! wxFileExists(LangPath))
	{
		ErrorMessage(wxT("Specified language.dll file does not exist."));
		return;
	}
	if (LangX1Path != wxT("") && ! wxFileExists(LangX1Path))
	{
		ErrorMessage(wxT("Specified language_x1.dll file does not exist."));
		return;
	}

	wxFileName GenieFileName = GeniePath;

	if (GenieFileName.GetName().Lower() == wxT("empires2"))
	{
		wxMessageDialog MsgBox (this, wxT("GeniEd2 cannot read the non-expansion AoK's empires2.dat. Try anyway?"), wxT("Warning"), wxYES_NO | wxCENTER | wxICON_EXCLAMATION);
		if (MsgBox.ShowModal() != wxID_YES)
		{
			return;
		}
	}
	wxRegEx ValidNames (wxT("^(empires2(_x1(_p1)?)?|genie(_x1)?)$"), wxRE_ICASE);
	if (! ValidNames.Matches(GenieFileName.GetName()))
	{
		wxMessageDialog MsgBox (this, wxString::Format(wxT("GeniEd2 only knows about genie(_x1) and empires2(_x1(_p1)) files -- \"%s\" is unrecognised. Continue anyway?"), GenieFileName.GetName()), wxT("Warning"), wxYES_NO | wxCENTER | wxICON_EXCLAMATION);
		if (MsgBox.ShowModal() != wxID_YES)
		{
			return;
		}
	}

	wxFileName GenieBackup = GenieFileName;
	GenieBackup.SetExt(wxT("bak"));
	if (! GenieBackup.FileExists())
	{
		wxMessageDialog MsgBox (this, wxString::Format(wxT("It'd be a good idea to back up \"%s\" - do you want me to automatically copy it to \"%s\"?"), GenieFileName.GetFullPath(), GenieBackup.GetFullPath()), wxT("Backup"), wxYES_NO);
		if (MsgBox.ShowModal() == wxID_YES)
		{
			if (! wxCopyFile(GenieFileName.GetFullPath(), GenieBackup.GetFullPath(), false))
			{
				wxLog::FlushActive();
				wxMessageDialog MsgBox2 (this, wxT("Hmm, that didn't work. Continuing without a backup."), wxT("Copy failure"), wxOK);
				MsgBox2.ShowModal();
			}
		}
	}

	config->Write(wxT("GeniePath"),	GeniePath);
	config->Write(wxT("LangPath"),	LangPath);
	config->Write(wxT("LangX1Path"),LangX1Path);

	EndModal(wxID_OK);
}

void OpenDialog::OnCancel(wxCommandEvent& WXUNUSED(event))
{
	EndModal(wxID_CANCEL);
}

wxString GetRegString(wxString path, wxString key)
{
	wxString value;
	wxRegKey *RegKey = new wxRegKey(path);
	if (RegKey->Exists())
		RegKey->QueryValue(key, value);
	delete RegKey;
	return value;
}

void OpenDialog::OnDefaultSWGB(wxCommandEvent& WXUNUSED(event))
{
	wxString InstallPath = GetRegString(wxT("HKEY_LOCAL_MACHINE\\SOFTWARE\\LucasArts Entertainment Company LLC\\Star Wars Galactic Battlegrounds\\1.0"), wxT("Install Path"));
	if (InstallPath.IsEmpty())
	{
		ErrorMessage(wxT("Unable to find SWGB registry key - you'll have to manually select the files."));
		return;
	}

	wxFileName geniefile (InstallPath, wxT(""));
	geniefile.AppendDir(wxT("Game"));
	geniefile.AppendDir(wxT("Data"));
	geniefile.SetFullName(wxT("genie.dat"));
	FilenameGenie->SetValue(geniefile.GetFullPath());

	wxFileName langfile (InstallPath, wxT(""));
	langfile.AppendDir(wxT("Game"));
	langfile.SetFullName(wxT("language.dll"));
	FilenameLang->SetValue(langfile.GetFullPath());

	FilenameLangX1->SetValue(wxT(""));
}
void OpenDialog::OnDefaultSWGBCC(wxCommandEvent& WXUNUSED(event))
{
	wxString InstallPath = GetRegString(wxT("HKEY_LOCAL_MACHINE\\SOFTWARE\\LucasArts Entertainment Company LLC\\Star Wars Galactic Battlegrounds\\1.0"), wxT("Install Path"));
	if (InstallPath.IsEmpty())
	{
		ErrorMessage(wxT("Unable to find SWGB registry key - you'll have to manually select the files."));
		return;
	}

	wxFileName geniefile (InstallPath, wxT(""));
	geniefile.AppendDir(wxT("Game"));
	geniefile.AppendDir(wxT("Data"));
	geniefile.SetFullName(wxT("genie_x1.dat"));
	FilenameGenie->SetValue(geniefile.GetFullPath());

	wxFileName langfile (InstallPath, wxT(""));
	langfile.AppendDir(wxT("Game"));
	langfile.SetFullName(wxT("language.dll"));
	FilenameLang->SetValue(langfile.GetFullPath());

	langfile.SetFullName(wxT("language_x1.dll"));
	FilenameLangX1->SetValue(langfile.GetFullPath());
}

void OpenDialog::OnDefaultAOKTC(wxCommandEvent& WXUNUSED(event))
{
	// I don't know which key it ought to use, so try 2.0 then 1.0
	wxString InstallPath = GetRegString(wxT("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Microsoft Games\\Age of Empires II: The Conquerors Expansion\\2.0"), wxT("EXE Path"));
	if (InstallPath.IsEmpty())
	{
		InstallPath = GetRegString(wxT("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Microsoft Games\\Age of Empires II: The Conquerors Expansion\\1.0"), wxT("EXE Path"));
		if (InstallPath.IsEmpty())
		{
			ErrorMessage(wxT("Unable to find AoK:TC registry key - you'll have to manually select the files."));
			return;
		}
	}
	FilenameGenie->SetValue(InstallPath + wxT("\\Data\\empires2_x1_p1.dat"));
	FilenameLang->SetValue(InstallPath + wxT("\\language.dll"));
	FilenameLangX1->SetValue(InstallPath + wxT("\\language_x1.dll"));

	wxFileName geniefile (InstallPath, wxT(""));
	geniefile.AppendDir(wxT("Data"));
	geniefile.SetFullName(wxT("empires2_x1_p1.dat"));
	// If that doesn't exist, try the unpatched one
	if (! geniefile.FileExists())
	{
		geniefile.SetFullName(wxT("empires2_x1.dat"));
		// Hmm, none of them exist, so just go back to the original guess
		if (! geniefile.FileExists())
			geniefile.SetFullName(wxT("empires2_x1_p1.dat"));
	}
	FilenameGenie->SetValue(geniefile.GetFullPath());

	wxFileName langfile (InstallPath, wxT(""));
	langfile.SetFullName(wxT("language.dll"));
	FilenameLang->SetValue(langfile.GetFullPath());

	langfile.SetFullName(wxT("language_x1.dll"));
	FilenameLangX1->SetValue(langfile.GetFullPath());

}


void OpenDialog::OnBrowseGenie(wxCommandEvent& WXUNUSED(event))
{
	wxConfig *config = (wxConfig *)wxConfig::Get();

	wxFileDialog OpenDialog(this, wxT(".dat file for input"), config->Read(wxT("BrowseDir Genie")), wxT(""), wxT("DAT files (*.dat)|*.dat"), wxOPEN | wxHIDE_READONLY | wxCHANGE_DIR);
	int retValue = OpenDialog.ShowModal();
	if (retValue != wxID_OK)
		return;

	wxFileName* FilePath = new wxFileName(OpenDialog.GetPath());
	config->Write(wxT("BrowseDir Genie"), FilePath->GetPath(wxPATH_GET_VOLUME));
	FilenameGenie->SetValue(FilePath->GetFullPath());
	delete FilePath;
}
void OpenDialog::OnBrowseLang(wxCommandEvent& WXUNUSED(event))
{
	wxConfig *config = (wxConfig *)wxConfig::Get();

	wxFileDialog OpenDialog(this, wxT("Main language.dll"), config->Read(wxT("BrowseDir Lang")), wxT("language.dll"), wxT("DLL files (*.dll)|*.dll"), wxOPEN | wxHIDE_READONLY | wxCHANGE_DIR);
	int retValue = OpenDialog.ShowModal();
	if (retValue != wxID_OK)
		return;

	wxFileName* FilePath = new wxFileName(OpenDialog.GetPath());
	config->Write(wxT("BrowseDir Lang"), FilePath->GetPath(wxPATH_GET_VOLUME));
	FilenameLang->SetValue(FilePath->GetFullPath());
	delete FilePath;
}
void OpenDialog::OnBrowseLangX1(wxCommandEvent& WXUNUSED(event))
{
	wxConfig *config = (wxConfig *)wxConfig::Get();

	wxFileDialog OpenDialog(this, wxT("Expansion language.dll"), config->Read(wxT("BrowseDir Lang")), wxT("language_x1.dll"), wxT("DLL files (*.dll)|*.dll"), wxOPEN | wxHIDE_READONLY | wxCHANGE_DIR);
	int retValue = OpenDialog.ShowModal();
	if (retValue != wxID_OK)
		return;

	wxFileName* FilePath = new wxFileName(OpenDialog.GetPath());
	config->Write(wxT("BrowseDir Lang"), FilePath->GetPath(wxPATH_GET_VOLUME));
	FilenameLangX1->SetValue(FilePath->GetFullPath());
	delete FilePath;
}

///////////////////////

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
	: wxFrame((wxFrame *)NULL, -1, title, pos, size, wxDEFAULT_FRAME_STYLE | wxCLIP_CHILDREN)
{
	SetIcon(wxIcon("IDI_ICON1"));

	// Create the menus
	wxMenuBar *menuBar = new wxMenuBar;

	// Create the File menu
	wxMenu *menuFile = new wxMenu;
	menuFile->Append(ID_Open, wxT("&Open..."), wxT("Select a .dat file (and optionally a language.dll file) to open"));
	menuFile->Append(ID_Save, wxT("&Save..."), wxT("Select a .dat file to save as"));
	menuFile->Append(ID_Revert, wxT("&Revert"), wxT("Destroys the current .dat file and replaces it with the backup copy. (You did agree to make a backup, didn't you?)"));
	#ifdef GED_DEV
	 menuFile->Append(ID_Dump, wxT("&Dump..."), wxT("Dump the uncompressed data to disk"));
	 menuFile->Append(ID_Test, wxT("_&Test..."), wxT("The magical mystery method"));
	#endif
	menuFile->AppendSeparator();
	menuFile->Append(ID_Quit, wxT("E&xit"), wxT("Close program"));

	menuBar->Append(menuFile, wxT("&File"));

	// Create the Tools menu
	wxMenu *menuTools = new wxMenu;
	menuTools->Append(ID_CopyCivs, wxT("&Copy to all civs"), wxT("Copies the stats of the selected unit onto the corresponding unit in every civ."));

	menuBar->Append(menuTools, wxT("&Tools"));

	// Create the Help menu
	wxMenu *menuHelp = new wxMenu;
	menuHelp->Append(ID_Help, wxT("&Help"), wxT("Information on how to use the program."));
	menuHelp->Append(ID_About, wxT("&About..."), wxT("About GeniEd2"));

	menuBar->Append(menuHelp, wxT("&Help"));

	SetMenuBar(menuBar);

	// Do a status bar

	CreateStatusBar();
	SetStatusText(wxT("GeniEd2 loaded"));

	
	// Create the two-panel split screen

	PanelSplit = new wxSplitterWindow(this, -1, wxDefaultPosition, wxDefaultSize, wxSP_3D | wxCLIP_CHILDREN);

	wxPanel *PanelLeft = new wxPanel(PanelSplit, -1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL | wxNO_BORDER | wxCLIP_CHILDREN);
	PanelRight = new UnitPanel(PanelSplit, NULL);

	PanelSplit->SplitVertically(PanelLeft, PanelRight, 175);

	// Fill panel0 with some stuff
	wxBoxSizer *PanelLeftSizer = new wxBoxSizer(wxVERTICAL);

	UnitCivList = new CivComboBox(PanelLeft, ID_CivSelect);
	UnitList = new UnitListBox(PanelLeft, ID_UnitSelect);
	UnitFilter = new wxTextCtrl(PanelLeft, ID_UnitFilter);

	PanelLeftSizer->Add(UnitCivList, 0, wxEXPAND);
	PanelLeftSizer->Add(UnitList, 1, wxEXPAND);
	PanelLeftSizer->Add(UnitFilter, 0, wxEXPAND);

	PanelLeft->SetSizer(PanelLeftSizer);

}


void ProgressDialogCallback(float Progress, void* data) {
	((wxProgressDialog *)data)->Update((int)(Progress*1024.0));
}

void MyFrame::OnOpen(wxCommandEvent& WXUNUSED(event))
{
	if (! PanelRight->SwitchAway())
		return;

	UnitPanel *NewPanel = new UnitPanel(PanelSplit, NULL);
	PanelSplit->ReplaceWindow(PanelRight, NewPanel);
	delete PanelRight;
	PanelRight = NewPanel;


	OpenDialog OpenBox (this);
	if (OpenBox.ShowModal() != wxID_OK)
		return;

	wxConfig *config = (wxConfig *)wxConfig::Get();

	wxString GeniePath, LangPath, LangX1Path;
	config->Read(wxT("GeniePath"),	&GeniePath);
	config->Read(wxT("LangPath"),	&LangPath);
	config->Read(wxT("LangX1Path"),	&LangX1Path);

	// Open the file

	delete MyApp::genie;
	PanelRight->RemoveUnit();

	MyApp::genie = new GenieFile;
	try
	{
		MyApp::genie->LoadGenie(GeniePath.ToAscii());
	}
	catch (char *msg)
	{
		ErrorMessage(wxString::FromAscii(msg));
		return;
	}
	catch (std::string msg)
	{
		ErrorMessage(wxString::FromAscii(msg.c_str()));
		return;
	}


	bool status;
	if (LangPath != wxT(""))
	{
		status = MyApp::genie->LoadLanguage(LangPath.c_str());
		if (status)
			ErrorMessage(wxT("Error loading language.dll - continuing without it."));
	}
	if (LangX1Path != wxT(""))
	{
		status = MyApp::genie->LoadLanguage(LangX1Path.c_str());
		if (status)
			ErrorMessage(wxT("Error loading language_x1.dll - continuing without it."));
	}

	wxProgressDialog *ProgressDialog = new wxProgressDialog(wxT("Progress"), wxT("Loading unit data..."), 1024, this, wxPD_APP_MODAL | wxPD_REMAINING_TIME);

	try
	{
		MyApp::genie->ReadUnitsData(&ProgressDialogCallback, ProgressDialog);
	}
	catch (char *msg)
	{
		ErrorMessage(wxString::FromAscii(msg));
		delete ProgressDialog;
		return;
	}

	MyFrame::UnitCivList->Reload();
	MyFrame::UnitCivList->Select(0);
	MyApp::CurrentCiv = MyApp::genie->Civs.front();

	MyFrame::UnitList->Reload();

	ProgressDialog->Destroy();

}

void MyFrame::OnSave(wxCommandEvent& WXUNUSED(event))
{
	if (! MyApp::genie)
	{
		wxLogError(wxT("Unable to save. Try opening first."));
		return;
	}
	if (! PanelRight->SwitchAway())
		return;

	wxConfig *config = (wxConfig *)wxConfig::Get();
	wxString GeniePath;
	config->Read(wxT("GeniePath"),	&GeniePath);
	wxFileName GenieFilename = GeniePath;

	wxFileDialog saveDialog(this, wxT("File to save as"), GenieFilename.GetPath(wxPATH_GET_VOLUME), GenieFilename.GetFullName(), wxT("DAT files (*.dat)|*.dat"), wxSAVE | wxOVERWRITE_PROMPT);
	int retValue = saveDialog.ShowModal();

	if (retValue == wxID_OK)
	{
		MyApp::genie->SaveGenie(saveDialog.GetPath().ToAscii());
	}
}

void MyFrame::OnDump(wxCommandEvent& WXUNUSED(event))
{
	if (! MyApp::genie)
	{
		wxLogError(wxT("Cannot dump the data file, since you never opened one."));
		return;
	}
	if (! PanelRight->SwitchAway())
		return;

	wxFileDialog saveDialog(this, wxT("File to dump to"), wxT(""), wxT(""), wxT("UNZ files (*.unz)|*.unz"), wxSAVE | wxOVERWRITE_PROMPT);
	int retValue = saveDialog.ShowModal();

	if (retValue == wxID_OK)
	{
		MyApp::genie->Dump(saveDialog.GetPath().ToAscii());
	}
}

void MyFrame::OnCopyCivs(wxCommandEvent& WXUNUSED(event))
{
	if (! PanelRight->SwitchAway())
		return;

	GenieUnit* CurrentUnit = PanelRight->Unit;
	genie_unit* CurrentUnitData = PanelRight->UnitData;

	for (GenieFile::CivsType::iterator Civ = MyApp::genie->Civs.begin(); Civ != MyApp::genie->Civs.end(); ++Civ)
	{
		if (*Civ == MyApp::CurrentCiv) continue; // i.e. don't continue. (Stupid language...)
		for (GenieCiv::UnitsType::iterator Unit = (*Civ)->Units.begin(); Unit != (*Civ)->Units.end(); ++Unit)
		{
			if (Unit->Id == CurrentUnit->Id)
			{
				Unit->DataBuffer->seek(Unit->FileOffset);
				CurrentUnitData->Write(Unit->DataBuffer, Unit->VersionNum);
				break;
			}
		}
	}
}

void MyFrame::OnRevert(wxCommandEvent& WXUNUSED(event))
{
	wxConfig *config = (wxConfig *)wxConfig::Get();

	wxString GeniePath;
	config->Read(wxT("GeniePath"),	&GeniePath);

	wxFileName GenieFilename = GeniePath;
	wxFileName GenieBakFilename = GenieFilename;
	GenieBakFilename.SetExt(wxT("bak"));

	wxMessageDialog MsgBox (this, wxString::Format(wxT("Overwrite \"%s\" with \"%s\"?\n(This won't reload the file - you probably want to Open it again to get the original)"), GenieFilename.GetFullPath(), GenieBakFilename.GetFullPath()), wxT("Overwrite"), wxOK | wxCANCEL);
	if (MsgBox.ShowModal() == wxID_OK)
	{
		if (! wxCopyFile(GenieBakFilename.GetFullPath(), GenieFilename.GetFullPath()))
		{
			wxLog::FlushActive();
			wxMessageDialog MsgBox2 (this, wxT("That didn't work."), wxT("Erk"), wxOK);
			MsgBox2.ShowModal();
		}
	}
}




void CivComboBox::Reload() 
{
	if (! MyApp::genie) {
		MyApp::CurrentCiv = NULL;
		Clear();
		return;
	}

	GenieFile::CivsType *Civs = &MyApp::genie->Civs;

	wxArrayString Names;
	void **ItemData = new void*[Civs->size()];

	int i=0;
	for (GenieFile::CivsType::iterator c = Civs->begin(); c != Civs->end(); ++c) {
		wxString Name = wxString::FromAscii((*c)->Title.c_str());

		// Change wxT("UPPERCASE") to wxT("Titlecase")
		Name.MakeLower();
		Name[(size_t)0] = toupper(Name[(size_t)0]);

		Names.Add(Name);
		ItemData[i++] = *c;
	}

	Clear();
	Append(Names);
	for (int j=0; j<i; ++j)
		SetClientData(j, ItemData[j]);

	delete[] ItemData;
}


void UnitListBox::Reload()
{
	if (! MyApp::CurrentCiv)
	{
		Clear();
		return;
	}

	GenieCiv::UnitsType *Units = &MyApp::CurrentCiv->Units;

	wxArrayString Names;
	void **ItemData = new void*[Units->size()]; // slightly larger than necessary, but it's not kept for very long

	/*	wxRE_NOCOMPLAIN is a flag I added to wxRegExpImpl::Compile in wx's
		src/common/regex.cpp, and to the enum in include/wx/regex.h,
		which disables the wxLogError message to avoid it complaining when
		it tries compiling half a regexp.
	*/
	wxRegEx *FilterRegEx = new wxRegEx(MyApp::UnitFilterText, wxRE_ICASE | wxRE_NOCOMPLAIN);

	bool NoFilter = (MyApp::UnitFilterText == wxT("") || !FilterRegEx->IsValid());

	Clear();

	int i=0;
	for (GenieCiv::UnitsType::iterator u = Units->begin(); u != Units->end(); ++u)
	{
		if (! NoFilter)
		{
			bool Matched = false;
			for (GenieUnit::SearchablesType::iterator i = u->Searchables.begin(); i != u->Searchables.end(); ++i)
			{
				if (FilterRegEx->Matches(wxString::FromAscii(i->ToAscii())))
				{
					Matched = true;
					break;
				}
			}
			if (! Matched) continue;
		}
		Names.Add(u->DisplayName);
		ItemData[i++] = &(*u);
	}

	if (Names.Count() == 0)
	{
		Names.Add(wxT("[no matches for filter]"));
		ItemData[0] = NULL;
	}

	Set(Names, ItemData);

	delete FilterRegEx;
	delete[] ItemData;
}

void MyFrame::OnCivSelect(wxCommandEvent& WXUNUSED(event))
{
	MyApp::CurrentCiv = (GenieCiv *)UnitCivList->GetClientData(UnitCivList->GetSelection());
	UnitList->Reload();
}

void MyFrame::OnUnitFilter(wxCommandEvent& WXUNUSED(event))
{
	MyApp::UnitFilterText = UnitFilter->GetValue();
	UnitList->Reload();
}

void MyFrame::OnUnitSelect(wxCommandEvent& WXUNUSED(event))
{
	if (! PanelRight->SwitchAway())
		return;

	int ScrollX, ScrollY;
	PanelRight->GetViewStart(&ScrollX, &ScrollY);

	UnitPanel *NewPanel = new UnitPanel(PanelSplit, (GenieUnit *)UnitList->GetClientData(UnitList->GetSelection()));

	PanelRight->Freeze();
	NewPanel->Freeze();

	PanelSplit->ReplaceWindow(PanelRight, NewPanel);

	NewPanel->FitInside();
	NewPanel->Scroll(ScrollX, ScrollY);

	PanelRight->Destroy();

	PanelRight = NewPanel;

	PanelRight->Thaw();
}


void MyFrame::OnTest(wxCommandEvent& WXUNUSED(event))
{
	// Do interesting stuff:


	// ...
}

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
	Close(TRUE);
}

void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
	wxMessageBox(wxT("GeniEd2 v1.0 - by Ykkrosh (ykkrosh@zaynar.demon.co.uk)"), wxT("About GeniEd2"), wxOK | wxICON_INFORMATION);
}

class HelpFrame : public wxFrame
{
public:
	HelpFrame()
		: wxFrame(NULL, -1, wxT("GeniEd2 Help"), wxDefaultPosition, wxSize(400, 400), wxDEFAULT_FRAME_STYLE)
	{
		wxHtmlWindow* Win = new wxHtmlWindow(this);
		#include "help.cpp"
		Win->SetPage(HtmlHelp);

	}
};

void MyFrame::OnHelp(wxCommandEvent& WXUNUSED(event))
{
	HelpFrame *F = new HelpFrame;
	F->Show();
}