#include "wx/wxprec.h"
#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "wx/msw/registry.h"
#include "wx/config.h"
#include "wx/splitter.h"
#include "wx/regex.h"
#include "wx/progdlg.h"

#include "wxunit.h"

#include <vector>

class MyApp: public wxApp
{
public:
	static GenieFile* genie;
	static GenieCiv* CurrentCiv;

	static wxString UnitFilterText;

private:

	virtual bool OnInit();
	virtual int OnExit();
	
};
GenieFile* MyApp::genie;
GenieCiv* MyApp::CurrentCiv;
wxString MyApp::UnitFilterText;


class UnitListBox : public wxListBox
{
public:
	UnitListBox(wxWindow *parent, wxWindowID id);
	void Reload();
};

class CivComboBox : public wxComboBox
{
public:
	CivComboBox(wxWindow *parent, wxWindowID id);
	void Reload();
};


class OpenDialog : public wxDialog
{
public:
	OpenDialog(wxWindow *parent);
	~OpenDialog();

	void OnOK(wxCommandEvent& event);
	void OnCancel(wxCommandEvent& event);

	void OnDefaultSWGB	(wxCommandEvent& event);
	void OnDefaultSWGBCC(wxCommandEvent& event);
	void OnDefaultAOKTC	(wxCommandEvent& event);
	void OnBrowseGenie	(wxCommandEvent& event);
	void OnBrowseLang	(wxCommandEvent& event);
	void OnBrowseLangX1	(wxCommandEvent& event);

private:
	DECLARE_EVENT_TABLE()

	wxTextCtrl* FilenameGenie;
	wxTextCtrl* FilenameLang;
	wxTextCtrl* FilenameLangX1;

	typedef std::vector<wxObject *> deletable_type;
	deletable_type deletable;
};

enum
{
//	ID_Open_Okay = 1,
//	ID_Open_Cancel,
	ID_Open_Default_SWGB = 1,
	ID_Open_Default_SWGBCC,
	ID_Open_Default_AOKTC,
	ID_Open_Browse_Genie,
	ID_Open_Browse_Lang,
	ID_Open_Browse_LangX1,
};

BEGIN_EVENT_TABLE(OpenDialog, wxDialog)
	//EVT_BUTTON(ID_Open_Okay,	OpenDialog::OnOkay)
	EVT_BUTTON(wxID_OK,	OpenDialog::OnOK)
	//EVT_BUTTON(ID_Open_Cancel,	OpenDialog::OnCancel)
	EVT_BUTTON(wxID_CANCEL,		OpenDialog::OnCancel)
	EVT_BUTTON(ID_Open_Default_SWGB,	OpenDialog::OnDefaultSWGB)
	EVT_BUTTON(ID_Open_Default_SWGBCC,	OpenDialog::OnDefaultSWGBCC)
	EVT_BUTTON(ID_Open_Default_AOKTC,	OpenDialog::OnDefaultAOKTC)
	EVT_BUTTON(ID_Open_Browse_Genie,	OpenDialog::OnBrowseGenie)
	EVT_BUTTON(ID_Open_Browse_Lang,		OpenDialog::OnBrowseLang)
	EVT_BUTTON(ID_Open_Browse_LangX1,	OpenDialog::OnBrowseLangX1)
END_EVENT_TABLE()



class MyFrame: public wxFrame
{
public:
	MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);

	void OnOpen(wxCommandEvent& event);
	void OnSave(wxCommandEvent& event);
	void OnDump(wxCommandEvent& event);
	void OnTest(wxCommandEvent& event);
	void OnQuit(wxCommandEvent& event);
	void OnRevert(wxCommandEvent& event);
	void OnAbout(wxCommandEvent& event);
	void OnHelp(wxCommandEvent& event);

	void OnCopyCivs(wxCommandEvent& event);

	void OnCivSelect(wxCommandEvent& event);
	void OnUnitFilter(wxCommandEvent& event);
	void OnUnitSelect(wxCommandEvent& event);

	UnitPanel* PanelRight;
	wxSplitterWindow* PanelSplit;
private:
	DECLARE_EVENT_TABLE()

	UnitListBox* UnitList;
	CivComboBox* UnitCivList;
	wxTextCtrl*  UnitFilter;
	
};

enum
{
	ID_Open = 1,
	ID_Save,
	ID_Quit,
	ID_Test,
	ID_Dump,
	ID_Revert,

	ID_Help,
	ID_About,

	ID_CopyCivs,

	ID_CivSelect,
	ID_UnitFilter,
	ID_UnitSelect,
};

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
	EVT_MENU(ID_Open,	MyFrame::OnOpen)
	EVT_MENU(ID_Save,	MyFrame::OnSave)
	EVT_MENU(ID_Dump,	MyFrame::OnDump)
	EVT_MENU(ID_Test,	MyFrame::OnTest)
	EVT_MENU(ID_Quit,	MyFrame::OnQuit)
	EVT_MENU(ID_Revert,	MyFrame::OnRevert)
	EVT_MENU(ID_CopyCivs,	MyFrame::OnCopyCivs)

	EVT_MENU(ID_Help,	MyFrame::OnHelp)
	EVT_MENU(ID_About,	MyFrame::OnAbout)

	EVT_COMBOBOX(ID_CivSelect,	MyFrame::OnCivSelect)
	EVT_TEXT	(ID_UnitFilter,	MyFrame::OnUnitFilter)
	EVT_LISTBOX	(ID_UnitSelect,	MyFrame::OnUnitSelect)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)

